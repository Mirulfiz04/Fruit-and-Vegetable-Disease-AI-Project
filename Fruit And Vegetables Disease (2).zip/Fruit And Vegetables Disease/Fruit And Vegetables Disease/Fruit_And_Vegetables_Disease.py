﻿# Enhanced and Interactive Fruit & Vegetable Disease Classifier UI

from keras.models import load_model
from PIL import Image, ImageOps, ImageTk
import numpy as np
import tkinter as tk
from tkinter import filedialog, ttk, messagebox
import cv2
import os
from datetime import datetime
import threading
import csv

try:
    from idlelib.tooltip import Hovertip
except ImportError:
    Hovertip = None

# --- Constants ---
MODEL_PATH = "keras_model.h5"
LABELS_PATH = "labels.txt"
HEALTH_IMAGE_DIR = "health_images"
IMAGE_SIZE = (224, 224)
DISPLAY_SIZE = (600, 600)  # Increased display size

# --- GUI Setup ---
root = tk.Tk()
root.title("Fruit & Vegetable Disease Classifier")
root.geometry("1200x800")
root.configure(bg="#f9f9f9")

# --- Banner Header with Title and Logo Below ---
banner = tk.Frame(root, bg="#dfe6e9", height=140)  # Increased height to fit logo
banner.pack(fill="x")

# Style for Title (Bigger Font)
style = ttk.Style()
style.configure("Title.TLabel", font=("Arial", 36, "bold"), background="#dfe6e9", foreground="#2c3e50")

# Title Label (on top)
title_label = ttk.Label(banner, text="Fruit & Vegetable Disease Classifier", style="Title.TLabel", anchor="center")
title_label.pack(pady=(25, 10))

# Logo Label (below title)
try:
    logo_img = Image.open("logo.png")  # Make sure logo.png exists
    logo_img = logo_img.resize((80, 80), Image.Resampling.LANCZOS)
    logo_photo = ImageTk.PhotoImage(logo_img)
    logo_label = tk.Label(banner, image=logo_photo, bg="#dfe6e9")
    logo_label.image = logo_photo  # Prevent garbage collection
    logo_label.pack(pady=(0, 10))  # Bottom padding
except:
    pass  # Skip if logo not found

# --- Globals ---
model = None
class_names = []
current_image = None
image_tk = None
camera_running = False
cap = None
bin_img_tk = None
last_classify_time = 0
auto_classify_enabled = tk.BooleanVar(value=True)


# --- Health Mapping ---
HEALTH_MAPPING = {
    "healthy": ("\u2705 Healthy", "#27ae60"),
    "rotten": ("\u274C Diseased/Rotten", "#e74c3c"),
    "unknown": ("\u2753 Unknown", "#95a5a6")
}

HEALTH_EXPLANATIONS = {
    "\u2705 Healthy": "This item is fresh and safe for consumption or sale.",
    "\u274C Diseased/Rotten": "This item is not suitable due to spoilage or disease. Dispose or inspect further.",
    "\u2753 Unknown": "Unable to determine. Please ensure good lighting and clear image."
}

STORAGE_TIPS = {
    "\u2705 Healthy": "Store in a cool, dry place or refrigerate to prolong freshness.",
    "\u274C Diseased/Rotten": "Dispose properly or isolate from healthy produce.",
    "\u2753 Unknown": "Recheck the item or take another photo."
}

ADDITIONAL_NOTES = {
    "\u2705 Healthy": "You can sell or consume this item without concern.",
    "\u274C Diseased/Rotten": "Do not mix with healthy produce to avoid contamination.",
    "\u2753 Unknown": "Consider using a higher quality image or different angle."
}

def is_blurry(image, threshold=100.0):
    """Check if an image is blurry based on Laplacian variance."""
    gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
    laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
    return laplacian_var < threshold

# --- Load Model ---
def load_ml_model():
    global model, class_names
    try:
        model = load_model(MODEL_PATH, compile=False)
        with open(LABELS_PATH, "r") as f:
            class_names = [line.strip().split(" ", 1)[-1] for line in f.readlines()]
        status_label.config(text="Model loaded successfully", fg="green")
    except Exception as e:
        status_label.config(text=f"Error loading model: {str(e)}", fg="red")
        messagebox.showerror("Model Load Error", str(e))


# --- Animate Progress ---
def animate_progress(target, current=0):
    if current <= target:
        progress['value'] = current
        root.after(10, lambda: animate_progress(target, current + 1))


# --- Camera Frame (with Auto-Classify) ---
def show_frame():
    global cap, current_image, image_tk, last_classify_time
    if not camera_running or cap is None:
        return

    ret, frame = cap.read()
    if ret:
        # Convert to RGB for display
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        current_image = Image.fromarray(rgb)

        # --- Simple color-based detection for red/orange/yellow fruit ---
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Adjust HSV range depending on your fruit/vegetable colors
        lower = np.array([0, 100, 100])
        upper = np.array([30, 255, 255])  # red/yellow/orange range

        mask = cv2.inRange(hsv, lower, upper)
        contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        # Draw bounding boxes on original RGB image
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 1000:  # Ignore small/noisy detections
                x, y, w, h = cv2.boundingRect(cnt)
                cv2.rectangle(rgb, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # Show the image with bounding boxes
        img = Image.fromarray(rgb)
        img.thumbnail(DISPLAY_SIZE)
        image_tk = ImageTk.PhotoImage(img)
        image_label.config(image=image_tk)
        image_label.image = image_tk

        # Auto-classify every 0.8 seconds
        now = datetime.now().timestamp()
        if auto_classify_enabled.get() and now - last_classify_time > 0.8:
            threading.Thread(target=classify_image, daemon=True).start()
            last_classify_time = now

    root.after(100, show_frame)



#--Classify--
def classify_image():
    global current_image, bin_img_tk
    if current_image is None or model is None:
        messagebox.showwarning("Warning", "Ensure image is loaded and model is ready.")
        return

    try:
        image = current_image.copy().convert("RGB")

        # Blurriness check
        if is_blurry(image):
            health_info = "\u2753 Unknown"
            status = "unknown"
            explain = "The image appears blurry, undetectable and unknown. Please retake the photo."
            storage = STORAGE_TIPS.get(health_info, "")
            action = "Retake image with better focus."
            note = "Hold the camera steady and ensure lighting."
            result_label.config(text=f"\U0001F50D Detected: Unknown")
            health_label.config(text=f"😄 Health Status: {health_info}")
            confidence_label.config(text=f"\U0001F4C8 Confidence: N/A")
            progress['value'] = 0
            time_label.config(text=f"\U0001F552 Time: {datetime.now().strftime('%d %B %Y, %I:%M %p')}")
            action_label.config(text=f"\U0001F4A1 Suggested Action: {action}")
            explanation_label.config(text=f"\U0001F9E0 Explanation:\n{explain}")
            storage_label.config(text=f"\U0001F4E6 Storage Tip:\n{storage}")
            note_label.config(text=f"📝 Additional Note:\n{note}")
            health_color_canvas.config(bg=HEALTH_MAPPING['unknown'][1])
            bin_image_label.config(image='', text="")
            return

        # --- Image preprocessing ---
        data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
        image = ImageOps.fit(image, (224, 224), Image.Resampling.LANCZOS)
        image_array = np.asarray(image)
        normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1
        data[0] = normalized_image_array

        # --- Prediction and Threshold ---
        prediction = model.predict(data)
        confidence_score = np.max(prediction)
        class_index = np.argmax(prediction)
        CONFIDENCE_THRESHOLD = 0.80

        if confidence_score < CONFIDENCE_THRESHOLD:
            item_name = "Unknown"
            health_info = "\u2753 Unknown"
            status = "unknown"
            top3_label.config(text="📊 Top 3 Predictions:\nNot confident enough.")
        else:
            raw_class_name = class_names[class_index].strip()
            class_parts = raw_class_name.lower().split("__")
            item_name = class_parts[0].title() if len(class_parts) > 0 else "Unknown"
            status = class_parts[1] if len(class_parts) > 1 else "unknown"
            health_info = HEALTH_MAPPING.get(status, ("\u2753 Unknown", "#95a5a6"))[0]

            # Show top 3 predictions
            top3_indices = prediction[0].argsort()[-3:][::-1]
            top3_text = "\U0001F4CA Top 3 Predictions:\n"
            for i in top3_indices:
                top3_text += f"{class_names[i]}: {prediction[0][i]:.2%}\n"
            top3_label.config(text=top3_text.strip())

        # --- Visual Feedback ---
        color = HEALTH_MAPPING.get(status if confidence_score >= CONFIDENCE_THRESHOLD else "unknown", (None, "#95a5a6"))[1]
        explain = HEALTH_EXPLANATIONS.get(health_info, "No explanation available.")
        storage = STORAGE_TIPS.get(health_info, "No storage tip available.")
        action = "Dispose immediately." if "Diseased" in health_info else "Keep in storage." if "Healthy" in health_info else "Inspect further."
        note = ADDITIONAL_NOTES.get(health_info, "No additional notes available.")

        now = datetime.now().strftime("%d %B %Y, %I:%M %p")
        result_label.config(text=f"\U0001F50D Detected: {item_name}")
        health_label.config(text=f"😄 Health Status: {health_info}")
        confidence_label.config(text=f"\U0001F4C8 Confidence: {confidence_score:.2%}")
        progress['value'] = 0
        progress['maximum'] = 100
        threading.Thread(target=animate_progress, args=(int(confidence_score * 100),)).start()
        time_label.config(text=f"\U0001F552 Time: {now}")
        action_label.config(text=f"\U0001F4A1 Suggested Action: {action}")
        explanation_label.config(text=f"\U0001F9E0 Explanation:\n{explain}")
        storage_label.config(text=f"\U0001F4E6 Storage Tip:\n{storage}")
        note_label.config(text=f"📝 Additional Note:\n{note}")
        health_color_canvas.config(bg=color)

        # Display health bin image if available
        img_key = "unknown" if item_name == "Unknown" else status
        img_path = os.path.join("health_images", f"{img_key}.png")
        if os.path.exists(img_path):
            img = Image.open(img_path)
            img.thumbnail((100, 100))
            bin_img_tk = ImageTk.PhotoImage(img)
            bin_image_label.config(image=bin_img_tk)
            bin_image_label.image = bin_img_tk
        else:
            bin_image_label.config(image='', text="")

        results_frame.configure(style="Highlight.TLabelframe")
        root.after(500, lambda: results_frame.configure(style="TLabelframe"))

    except Exception as e:
        messagebox.showerror("Classification Error", str(e))

# --- Load Image ---
def open_image():
    global current_image, image_tk
    path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp")])
    if not path:
        return
    current_image = Image.open(path)
    display_img = current_image.copy()
    display_img.thumbnail(DISPLAY_SIZE)
    image_tk = ImageTk.PhotoImage(display_img)
    image_label.config(image=image_tk, text="")
    image_label.image = image_tk
    classify_btn.config(state="normal")
    status_label.config(text=f"Loaded: {os.path.basename(path)}", fg="blue")


# --- Start & Stop Camera ---
def start_camera():
    global cap, camera_running
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    camera_running = True
    classify_btn.config(state="normal")
    show_frame()

def stop_camera():
    global cap, camera_running
    camera_running = False
    if cap:
        cap.release()
        cap = None
    if current_image is None:
        classify_btn.config(state="disabled")



# --- UI Setup ---
root.geometry("1300x900")
root.configure(bg="#f9f9f9")

# --- UI Layout ---
ttk.Style().configure("Title.TLabel", font=("Arial", 30, "bold"), background="#f9f9f9")


# Button styles
style = ttk.Style()
style.theme_use("default")

style.configure("Blue.TButton", foreground="white", background="#3498db", font=("Arial", 11, "bold"), padding=6)
style.map("Blue.TButton", background=[("active", "#2980b9")])

style.configure("Green.TButton", foreground="white", background="#27ae60", font=("Arial", 11, "bold"), padding=6)
style.map("Green.TButton", background=[("active", "#1e8449")])

style.configure("Orange.TButton", foreground="white", background="#e67e22", font=("Arial", 11, "bold"), padding=6)
style.map("Orange.TButton", background=[("active", "#ca6f1e")])

style.configure("Purple.TButton", foreground="white", background="#9b59b6", font=("Arial", 11, "bold"), padding=6)
style.map("Purple.TButton", background=[("active", "#884ea0")])


main_frame = ttk.Frame(root)
main_frame.pack(fill="both", expand=True, padx=20, pady=10)

image_frame = ttk.LabelFrame(main_frame, text="Selected Image", width=620, height=620)  # Increased size
image_frame.pack(side="left", fill="both", expand=True)
image_frame.pack_propagate(False)  # Prevent shrinking to fit content
image_label = tk.Label(image_frame, text="No image selected", bg="white", fg="gray", relief="solid")
image_label.pack(padx=10, pady=10, fill="both", expand=True)

results_frame = ttk.LabelFrame(main_frame, text="Classification Results")
results_frame.pack(side="right", fill="both", expand=True, padx=(10, 0))

health_color_frame = ttk.Frame(results_frame)
health_color_frame.pack(pady=5)
tk.Label(health_color_frame, text="Health Indicator:").pack(side="left")
health_color_canvas = tk.Canvas(health_color_frame, width=30, height=30, bg="#f0f0f0", highlightbackground="black")
health_color_canvas.pack(side="left", padx=5)

bin_image_label = tk.Label(results_frame, bg="#f9f9f9")
bin_image_label.pack(pady=(0, 5))

ttk.Separator(results_frame, orient="horizontal").pack(fill="x", padx=5, pady=3)

result_label = tk.Label(results_frame, text="🔍 Detected: -", font=("Arial", 12))
result_label.pack(anchor="w", padx=10)
health_label = tk.Label(results_frame, text="😄 Health Status: -", font=("Arial", 12), anchor="w", justify="left")
health_label.pack(anchor="w", padx=10)
confidence_label = tk.Label(results_frame, text="📈 Confidence: -", font=("Arial", 12))
confidence_label.pack(anchor="w", padx=10)
progress = ttk.Progressbar(results_frame, orient="horizontal", length=200, mode="determinate")
progress.pack(pady=5)

ttk.Separator(results_frame, orient="horizontal").pack(fill="x", padx=5, pady=3)

time_label = tk.Label(results_frame, text="🕒 Time: -", font=("Arial", 12))
time_label.pack(anchor="w", padx=10)
action_label = tk.Label(results_frame, text="💡Suggested Action: -", font=("Arial", 12))
action_label.pack(anchor="w", padx=10)

ttk.Separator(results_frame, orient="horizontal").pack(fill="x", padx=5, pady=3)

explanation_label = tk.Label(results_frame, text="🧠 Explanation:", font=("Arial", 12), justify="left", wraplength=350)
explanation_label.pack(anchor="w", padx=10)

ttk.Separator(results_frame, orient="horizontal").pack(fill="x", padx=5, pady=3)

storage_label = tk.Label(results_frame, text="📦 Storage Tip:", font=("Arial", 12), justify="left", wraplength=350)
storage_label.pack(anchor="w", padx=10)

control_frame = ttk.Frame(root)
control_frame.pack(fill="x", padx=20, pady=(0, 10))

open_btn = ttk.Button(control_frame, text="📁 Open Image", style="Blue.TButton", command=open_image)
open_btn.pack(side="left", padx=8)
if Hovertip: Hovertip(open_btn, "Select an image from your computer")

camera_btn = ttk.Button(control_frame, text="📷 Start Camera", style="Green.TButton", command=start_camera)
camera_btn.pack(side="left", padx=8)
if Hovertip: Hovertip(camera_btn, "Start your webcam for live classification")

stop_btn = ttk.Button(control_frame, text="🛑 Stop Camera", style="Orange.TButton", command=stop_camera)
stop_btn.pack(side="left", padx=8)
if Hovertip: Hovertip(stop_btn, "Stop the camera stream")

classify_btn = ttk.Button(control_frame, text="🔍 Classify", style="Purple.TButton", command=classify_image, state="disabled")
classify_btn.pack(side="left", padx=8)
if Hovertip: Hovertip(classify_btn, "Classify the loaded image or camera frame")

# Define a style for interactive checkbutton
style.configure("Auto.TCheckbutton",
                font=("Arial", 11, "bold"),
                foreground="#2c3e50",
                background="#ecf0f1",
                padding=6)

# Function to update text based on toggle state
def update_auto_label():
    state = "🟢 Enabled" if auto_classify_enabled.get() else "🔴 Disabled"
    auto_check.config(text=f"🤖 Auto-Classify: {state}")

# Checkbox with dynamic label
auto_check = ttk.Checkbutton(control_frame,
                             variable=auto_classify_enabled,
                             command=update_auto_label,
                             style="Auto.TCheckbutton")
auto_check.pack(side="left", padx=8)

# Initialize label correctly
update_auto_label()

if Hovertip:
    Hovertip(auto_check, "Toggle automatic classification when using webcam")

status_frame = ttk.Frame(root, relief="sunken", border=1)
status_frame.pack(fill="x", side="bottom", ipady=3)
status_label = tk.Label(status_frame, text="Loading model...", anchor="w")
status_label.pack(fill="x", padx=10)

top3_label = ttk.Label(results_frame, text="📊 Top 3 Predictions:", font=("Segoe UI", 10, "bold"))
top3_label.pack(anchor="w", padx=10, pady=(5, 10))

note_label = tk.Label(results_frame, text="📝 Additional Note:", font=("Arial", 12), anchor="w", justify="left", wraplength=350)
note_label.pack(anchor="w", padx=10, pady=(5, 10))

CSV_FILENAME = "classification_history.csv"

def save_to_csv():
    if result_label.cget("text") == "🔍 Detected: -":
        messagebox.showwarning("No Data", "No classification result to save.")
        return

    data_row = [
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        result_label.cget("text").replace("🔍 Detected: ", ""),
        health_label.cget("text").replace("😄 Health Status: ", ""),
        confidence_label.cget("text").replace("📈 Confidence: ", ""),
        action_label.cget("text").replace("💡Suggested Action: ", ""),
    ]

    file_exists = os.path.isfile(CSV_FILENAME)

    try:
        with open(CSV_FILENAME, mode="a", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            if not file_exists:
                writer.writerow(["Timestamp", "Detected Item", "Health Status", "Confidence", "Suggested Action"])
            writer.writerow(data_row)
        messagebox.showinfo("Saved", "Classification result saved to history.")
    except Exception as e:
        messagebox.showerror("Save Error", f"Failed to save CSV: {e}")

save_btn = ttk.Button(control_frame, text="💾 Save to CSV", style="Blue.TButton", command=save_to_csv)
save_btn.pack(side="left", padx=8)
if Hovertip: Hovertip(save_btn, "Save the latest classification result to history.csv")

style = ttk.Style()
style.theme_use("default")
style.configure("Highlight.TLabelframe", background="#ffffcc")

# Start loading model after GUI is ready
root.after(100, load_ml_model)
root.mainloop()

